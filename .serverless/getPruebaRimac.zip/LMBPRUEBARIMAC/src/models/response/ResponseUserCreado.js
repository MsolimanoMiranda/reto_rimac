class ResponseUserCreado {
  constructor({
    codigo_usuario = undefined
  }) {
    this.codigo_usuario = codigo_usuario
  }
}

module.exports = ResponseUserCreado;