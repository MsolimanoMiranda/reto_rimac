class DetalleRes {
    constructor({

      descripcion =undefined
    }) {

      this.descripcion = descripcion
    }
  }
  
  module.exports = DetalleRes;
